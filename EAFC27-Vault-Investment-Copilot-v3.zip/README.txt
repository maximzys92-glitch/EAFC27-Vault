EAFC27 Vault – Investment Copilot

Diese Version enthält die echte Trading-Oberfläche:
- 50K / 100K / 250K / 500K / 750K / 1M
- BUY/WATCH
- Kauf-Limit, Zielverkauf, Menge
- 5% EA-Steuer
- Gewinn/ROI-Berechnung
- eigenes Trade-Journal mit localStorage
- automatische Neuberechnung alle 15 Minuten
- vorbereitet für eine erlaubte Live-Marktdatenquelle

Wichtig:
Die Seite enthält absichtlich KEINE EA-Anmeldedaten und KEINEN Autobuyer.
Die aktuelle öffentliche GitHub-Pages-Datei kann ohne angebundene Datenquelle keine echten Live-Marktpreise garantieren.
Für echte automatische Marktaktualisierung muss VAULT_DATA_URL auf einen zulässigen, stabilen FC-27-Marktdaten-Endpunkt zeigen.
FCUTeam beschreibt seine FC-27-Marktpreise als Community-Transfermarktpreise und aktualisiert diese laut eigener Dokumentation stündlich.
